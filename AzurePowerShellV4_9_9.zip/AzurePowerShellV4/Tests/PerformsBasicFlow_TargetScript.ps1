# Return key information.
New-Object psobject -Property @{
    Args = $args
}